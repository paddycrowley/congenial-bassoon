
# One-click Bicep pipeline (Event Grid + CDN + SWA + Functions + Cosmos + KV)

This repo includes an **Azure Bicep** template and a **GitHub Actions** workflow to deploy your full race photo stack:
- Storage Account with **raw** and **thumbs** containers
- Azure Functions (Consumption) with system-assigned identity
- Cosmos DB (serverless) + three containers (`photos`, `consents`, `persons`)
- **Azure Front Door (Standard)** for CDN delivery of `/photos/thumbs/*`
- Event Grid **system topic** on Storage + **event subscription** to the Function for **BlobCreated** in `photos/raw/`
- Azure Key Vault (RBAC) + role assignment (Secrets User) for the Function
- Azure **Static Web Apps** (wired to your GitHub repo)

## How it works (design references)
- Front Door can cache and route static content from **Blob Storage** origins, improving global performance and enabling WAF/HTTPS at the edge. [Microsoft Learn reference](https://learn.microsoft.com/en-us/azure/frontdoor/scenario-storage-blobs)  
- Event Grid **system topics** represent events from services (e.g., Storage) and you can create **event subscriptions** that deliver **BlobCreated** to Azure Functions; the tutorial shows Bicep subscriptions. [Event Grid Bicep quickstart](https://learn.microsoft.com/en-us/azure/event-grid/blob-event-quickstart-bicep)  
- Cosmos DB accounts, databases, and containers can be created and managed with Bicep; samples show serverless and autoscale patterns. [Manage Cosmos DB with Bicep](https://learn.microsoft.com/en-us/azure/cosmos-db/nosql/manage-with-bicep)  
- Azure Functions can reference **Key Vault secrets** with app settings, using managed identity and Key Vault references. [Key Vault references for App Service/Functions](https://learn.microsoft.com/en-us/azure/app-service/app-service-key-vault-references)
- Static Web Apps has an ARM/Bicep resource (`Microsoft.Web/staticSites`) with repository/branch and build properties. [Static Web Apps Bicep ref](https://learn.microsoft.com/en-us/azure/templates/microsoft.web/staticsites)

## Prereqs
1. Create a resource group (e.g., `rg-racephoto-prod`).  
2. In GitHub repo **Secrets and variables**: add `AZURE_CLIENT_ID`, `AZURE_TENANT_ID`, `AZURE_SUBSCRIPTION_ID` (OIDC app registration / federated credentials). Set `AZURE_RG` as a repo variable.  
3. Update `infra/parameters.dev.json` with your `namePrefix`, location, and `repoUrl`.

## Deploy
- Run the workflow **Deploy Infra (Bicep)** on `main`, or push changes under `/infra`.

## Notes
- The Event Grid subscription targets the function `blobThumbDetect` (adjust to your actual function name). Blob trigger 5.x uses **event-based** subscriptions for low latency.  
- If you later enable **Private Link** between Front Door and Storage, follow the premium guide.  
- We set `FACE_IDENTIFY_ENABLED=false` by default; flip it only after Limited Access approval.

## Next
- Add Front Door **custom domain** & WAF if needed.  
- Use Key Vault references in Function app settings instead of raw keys, and assign RBAC roles or access policies.  
- Add additional CDN routes for other asset paths.
